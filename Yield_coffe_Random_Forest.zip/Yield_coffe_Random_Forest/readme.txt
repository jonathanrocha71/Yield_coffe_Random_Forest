REMOTE EVALUATION OF THE YIELD OF COFFEE 

Title of the manuscript "REMOTE EVALUATION OF THE YIELD OF COFFEE FRUIT BY MACHINE LEARNING TECHNIQUES AND SPECTRAL AGROMETEOROLOGICAL MODEL "

Jonathan da Rocha Miranda
Doctor of Agricultural Engineering
Agricultural Engineering Department, 
Federal University of Lavras, University Campus,
P.O.Box 3037, 37200-000, Lavras, Minas Gerais, Brazil
 
jhonerocha@estudante.ufla.br


